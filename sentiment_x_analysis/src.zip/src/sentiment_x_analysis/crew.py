import os
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai.agents.agent_builder.base_agent import BaseAgent
from typing import List
from dotenv import load_dotenv

# Fix import paths - use relative imports
try:
    from .tools.custom_scraper_tool import ScrapeXTool
    from .tools.pdf_write import PDFWriterTool
except ImportError:
    # Fallback for direct execution
    import sys
    from pathlib import Path
    sys.path.append(str(Path(__file__).parent))
    from tools.custom_scraper_tool import ScrapeXTool
    from tools.pdf_write import PDFWriterTool

import json
from datetime import datetime

# Load environment variables
load_dotenv()

# Validate environment variables with better error messages
if os.getenv("GROQ_API_KEY") is None:
    print("ERROR: GROQ_API_KEY is not set in the .env file.")
    print("Please add your Groq API key to the .env file")
    raise ValueError("GROQ_API_KEY is not set in the .env file.")

if os.getenv("MODEL") is None:
    print("WARNING: MODEL is not set in the .env file. Using default.")
    os.environ["MODEL"] = "llama-3.1-70b-versatile"

@CrewBase
class SentimentXAnalysis():
    """Enhanced SentimentXAnalysis crew with proper tool integration"""

    agents: List[BaseAgent]
    tasks: List[Task]
    
    # Target usernames for analysis
    TARGET_USERNAMES = [
        "elonmusk", "naval", "chamath", "garyvee", "balajis",
        "cdixon", "aronvanammers", "aantonop", "VitalikButerin", "satyanadella"
    ]

    @agent
    def x_data_collector(self) -> Agent:
        """Data collection agent with scraping capabilities"""
        try:
            scrape_tool = ScrapeXTool()
            return Agent(
                config=self.agents_config['x_data_collector'],
                verbose=True,
                tools=[scrape_tool],
                max_execution_time=600,
                max_iter=3
            )
        except Exception as e:
            print(f"Warning: Could not initialize ScrapeXTool: {e}")
            return Agent(
                config=self.agents_config['x_data_collector'],
                verbose=True,
                tools=[],  # No tools if initialization fails
                max_execution_time=600,
                max_iter=3
            )

    @agent
    def sentiment_analyzer(self) -> Agent:
        """Sentiment analysis agent with LLM capabilities"""
        return Agent(
            config=self.agents_config['sentiment_analyzer'],
            verbose=True,
            max_execution_time=300,
            max_iter=2
        )

    @agent
    def output_structurer(self) -> Agent:
        """Output structuring and organization agent"""
        return Agent(
            config=self.agents_config['output_structurer'],
            verbose=True,
            max_execution_time=180,
            max_iter=2
        )

    @agent
    def report_generator(self) -> Agent:
        """Report generation agent with PDF capabilities"""
        try:
            pdf_tool = PDFWriterTool()
            return Agent(
                config=self.agents_config['report_generator'],
                verbose=True,
                tools=[pdf_tool],
                max_execution_time=240,
                max_iter=2
            )
        except Exception as e:
            print(f"Warning: Could not initialize PDFWriterTool: {e}")
            return Agent(
                config=self.agents_config['report_generator'],
                verbose=True,
                tools=[],  # No tools if initialization fails
                max_execution_time=240,
                max_iter=2
            )

    @task
    def scrape_tweets_task(self) -> Task:
        """Scrape tweets from selected X/Twitter creators."""
        return Task(
            config=self.tasks_config.get('scrape_tweets_task', {}),
            agent=self.x_data_collector(),  # Your agent for scraping
            expected_output="""
                Structured JSON containing:
                - Tweet text & timestamp
                - Engagement metrics (likes, retweets, replies, views)
                - User profile info (followers, following, bio)
                - Tweet metadata (hashtags, mentions, URLs)
            """
        )

    @task
    def analyze_sentiment_task(self) -> Task:
        """Perform sentiment analysis on collected tweets."""
        return Task(
            config=self.tasks_config.get('analyze_sentiment_task', {}),
            agent=self.sentiment_analyzer(),  # Your sentiment analysis agent
            # Context references tasks by string name
            context=["scrape_tweets_task"],
            expected_output="Detailed sentiment analysis for all collected tweets"
        )

    @task
    def structure_output_task(self) -> Task:
        """Structure the final output for reporting."""
        return Task(
            config=self.tasks_config.get('structure_output_task', {}),
            agent=self.output_structurer(),  # Use existing output_structurer agent
            context=[
                "scrape_tweets_task",
                "analyze_sentiment_task"
            ],
            expected_output="Final JSON/CSV/PDF report ready for export"
        )

    @task
    def generate_report_task(self) -> Task:
        """Generate PDF report."""
        return Task(
            config=self.tasks_config.get('generate_report_task', {}),
            agent=self.report_generator(),  # Use existing report_generator agent
            context=[
                "scrape_tweets_task",
                "analyze_sentiment_task",
                "structure_output_task"
            ],
            expected_output="Professional PDF report with visualizations and insights"
        )


    @crew
    def crew(self) -> Crew:
        """Enhanced CrewAI crew with proper task dependencies"""
        return Crew(
            agents=self.agents,
            tasks=self.tasks,
            process=Process.sequential,
            verbose=True,
            memory=True,  # Enable memory for better context retention
        )
    
    def kickoff_with_inputs(self, inputs: dict = None):
        """Kickoff crew with optional inputs"""
        if inputs is None:
            inputs = {
                "usernames": ",".join(self.TARGET_USERNAMES),
                "tweet_count": 50,
                "analysis_focus": "sentiment, financial_tickers, themes"
            }
        
        return self.crew().kickoff(inputs=inputs)
    
    def get_target_usernames(self):
        """Get the list of target usernames"""
        return self.TARGET_USERNAMES