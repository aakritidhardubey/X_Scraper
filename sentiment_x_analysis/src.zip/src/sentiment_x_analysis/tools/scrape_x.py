import snscrape.modules.twitter as sntwitter
from crewai_tools import Tool

def scrape_x_user_tweets(username, max_tweets=200):
    tweets_list = []
    for i, tweet in enumerate(sntwitter.TwitterUserScraper(username).get_items()):
        if i >= max_tweets:
            break
        tweets_list.append(tweet.content)
    return tweets_list
